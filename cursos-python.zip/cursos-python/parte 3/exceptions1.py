try:
    6/0
except Exception as e:
    #pass
    print("%s" % e)
    raise e

print("Despues")
