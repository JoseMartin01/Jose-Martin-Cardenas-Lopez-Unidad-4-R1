try:
    6/0
except ZeroDivisionError:
    print("Error")
