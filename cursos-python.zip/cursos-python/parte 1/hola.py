print ("Hola Platzi")
print ("Hola Mundo")
print ("Hola Fabian")
print ("COmo estan")
print ("Hola Gente")
print ("Hola Colombia")
print ("Hola jupoxg")



